// ═══════════════════════════════════════════════════════════
// Service Worker — موقع الوزيري لتبادل الملفات
// Cache-First Strategy + Background Sync للطابور
// ═══════════════════════════════════════════════════════════

const CACHE_VERSION = 'ft-cache-v20';
const CACHE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-v3.svg',
  './icon-v4.svg',
  './qrcode.min.js',
  './pako.min.js',
  './jsQR.js',
  './peerjs.min.js',
  './js/config.js',
  './js/supabase-client.js',
  './js/stats-tracker.js',
  './js/session-manager.js'
];

// ─── Install ───
self.addEventListener('install', event => {
  console.log('[SW] Installing ' + CACHE_VERSION + '...');
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then(cache => cache.addAll(CACHE_ASSETS).catch(err => {
        console.warn('[SW] Some files failed to cache:', err);
      }))
      .then(() => self.skipWaiting())
  );
});

// ─── Activate ───
self.addEventListener('activate', event => {
  console.log('[SW] Activating ' + CACHE_VERSION + '...');
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys
          .filter(k => k !== CACHE_VERSION)
          .map(k => {
            console.log('[SW] Deleting old cache:', k);
            return caches.delete(k);
          })
      ))
      .then(() => self.clients.claim())
  );
});

// ─── Fetch ───
self.addEventListener('fetch', event => {
  const req = event.request;

  // تجاهل الطلبات غير GET والموارد الخارجية
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // ═══ التنقل/الصفحات ═══
  if (req.mode === 'navigate' || req.destination === 'document') {
    const reqPath = url.pathname;
    const isMainApp = (reqPath === '/' || reqPath === '/index.html' || reqPath === '');

    // لوحة المطور (أو أي مسار غير الرئيسي) → Network First
    if (!isMainApp) {
      event.respondWith(
        fetch(req).catch(() =>
          caches.match(req).then(cached =>
            cached || new Response(
              '<h1>Offline</h1><p>هذه الصفحة تحتاج إنترنت.</p>',
              { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
            )
          )
        )
      );
      return;
    }

    // الصفحة الرئيسية → Cache First
    event.respondWith(
      caches.match('./index.html').then(cached => {
        if (cached) {
          // تحديث صامت في الخلفية
          fetch(req).then(res => {
            if (res && res.status === 200) {
              const clone = res.clone();
              caches.open(CACHE_VERSION).then(c => c.put(req, clone)).catch(() => {});
            }
          }).catch(() => {});
          return cached;
        }
        return fetch(req).then(res => {
          if (res && res.status === 200) {
            const clone = res.clone();
            caches.open(CACHE_VERSION).then(c => c.put(req, clone)).catch(() => {});
          }
          return res;
        }).catch(() =>
          new Response(
            '<h1>Offline</h1><p>Connect once to install the app.</p>',
            { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
          )
        );
      })
    );
    return;
  }

  // ═══ الموارد الأخرى → Cache First ═══
  event.respondWith(
    caches.match(req).then(cached => {
      if (cached) return cached;
      return fetch(req).then(res => {
        if (!res || res.status !== 200 || res.type === 'opaque') return res;
        const clone = res.clone();
        caches.open(CACHE_VERSION).then(c => c.put(req, clone)).catch(() => {});
        return res;
      }).catch(() => new Response('', { status: 404 }));
    })
  );
});

// ═══════════════════════════════════════════════════════════
// Background Sync — لطابور ملفات LAN
// ═══════════════════════════════════════════════════════════
self.addEventListener('sync', event => {
  if (event.tag !== 'lan-file-queue') return;

  event.waitUntil(
    self.clients.matchAll({ includeUncontrolled: true, type: 'window' })
      .then(clients => {
        if (!clients || clients.length === 0) return;
        clients.forEach(client => {
          try {
            client.postMessage({ type: 'drain-lan-queue' });
          } catch (e) {
            console.warn('[SW] postMessage failed:', e);
          }
        });
      })
  );
});

// ─── Message handler ───
self.addEventListener('message', event => {
  if (event.data === 'skipWaiting') { self.skipWaiting(); return; }
  if (event.data && typeof event.data === 'object' && event.data.type === 'skipWaiting') {
    self.skipWaiting();
  }
});
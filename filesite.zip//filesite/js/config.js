// ═══════════════════════════════════════════════════════════
// config.js — إعدادات مشتركة بين كل ملفات الإحصائيات
// ═══════════════════════════════════════════════════════════
(function(){
  'use strict';

  window.WaziriConfig = {
    // ═══ عتبة اعتبار الجلسة "مهجورة" (10 دقائق) ═══
    ABANDON_MS: 10 * 60 * 1000,

    // ═══ المفاتيح في localStorage ═══
    KEY_NAME: 'ft-myname-v1',
    KEY_DEVICE_ID: 'ft-device-id',
    KEY_SESSION: 'ft-last-session-v1',
    KEY_SUPABASE_SESSION_ID: 'ft-supabase-session-id',

    // ═══ حالات الجلسة ═══
    STATE_ACTIVE: 'active',
    STATE_COMPLETED: 'completed',
    STATE_CANCELLED: 'cancelled',
    STATE_ABANDONED: 'abandoned',

    // ═══ معرّف الجهاز الفريد ═══
    getDeviceId: function(){
      try {
        var id = localStorage.getItem(this.KEY_DEVICE_ID);
        if (!id) {
          id = 'dev-' + Math.random().toString(36).substr(2, 10) +
               Date.now().toString(36).substr(-4);
          localStorage.setItem(this.KEY_DEVICE_ID, id);
        }
        return id;
      } catch(e) {
        return 'dev-temp-' + Math.random().toString(36).substr(2, 10);
      }
    },

    // ═══ الاسم الحالي من localStorage ═══
    getUserName: function(){
      try {
        var n = localStorage.getItem(this.KEY_NAME);
        return (n && n.trim()) ? n.trim() : null;
      } catch(e) { return null; }
    },

    // ═══ حفظ الاسم ═══
    setUserName: function(name){
      try {
        if (name && name.trim()) {
          localStorage.setItem(this.KEY_NAME, name.trim());
          return true;
        }
      } catch(e) {}
      return false;
    }
  };

})();
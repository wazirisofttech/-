// ═══════════════════════════════════════════════════════════
// supabase-client.js
// تهيئة الاتصال بـ Supabase — طبقة واحدة بسيطة
// ═══════════════════════════════════════════════════════════
(function(){
  'use strict';

  // ═══ إعدادات المشروع ═══
  var SUPABASE_URL = 'https://hfohamdjngwlpkkemylz.supabase.co';
  var SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhmb2hhbWRqbmd3bHBra2VteWx6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0NzE1MTAsImV4cCI6MjEwNTA0NzUxMH0.JRrbNibX5HzZ15UwEAbGHjIwFwsxtPj6jElKZShQ6R0';

  var client = null;

  try {
    // المكتبة تُحمّل من CDN — اسم المتغير العام: supabase
    if (typeof supabase !== 'undefined' && typeof supabase.createClient === 'function') {
      client = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          storageKey: 'waziri-sb-auth'
        }
      });
      console.log('[Supabase] ✅ Connected to', SUPABASE_URL);
    } else {
      console.warn('[Supabase] ⚠️ Library not loaded — stats disabled');
    }
  } catch (e) {
    console.warn('[Supabase] ❌ Init error:', e);
  }

  // ═══ الواجهة العامة ═══
  window.WaziriSB = {
    client: client,
    url: SUPABASE_URL,
    isReady: function(){ return client !== null; }
  };

})();